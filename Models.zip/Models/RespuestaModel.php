<?php

namespace App\Models;

use CodeIgniter\Model;

class RespuestaModel extends Model
{
    protected $table = 'Respuesta';
    protected $primaryKey = 'id_respuesta';

    protected $allowedFields = [
        'respuesta_usuario',
        'id_usuario',
        'id_pregunta'
    ];

    protected $useTimestamps = false;
}
