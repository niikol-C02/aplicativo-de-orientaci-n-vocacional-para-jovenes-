<?php

namespace App\Models;

use CodeIgniter\Model;

class RecomendacionModel extends Model
{
  protected $table = 'Recomendacion';
    protected $primaryKey = 'id_recomendacion';

    protected $allowedFields = [
        'id_usuario',
        'id_carrera',
        'porcentaje',
    ];

    protected $useTimestamps = false;
}
