<?php

namespace App\Models;

use CodeIgniter\Model;

class CarreraModel extends Model
{
    protected $table = 'Carrera';
    protected $primaryKey = 'id_carrera';

    protected $allowedFields = [
        'nom_carrera',
        'descripcion',
        'area',
        'id_universidad'
    ];

    protected $useTimestamps = false;
