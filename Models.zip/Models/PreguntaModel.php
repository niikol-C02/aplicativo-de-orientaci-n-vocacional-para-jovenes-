<?php

namespace App\Models;

use CodeIgniter\Model;

class PreguntaModel extends Model
{
    protected $table = 'Pregunta';
    protected $primaryKey = 'id_pregunta';

    protected $allowedFields = [
        'texto_pregunta',
        'id_test'
    ];

    protected $useTimestamps = false;
}
