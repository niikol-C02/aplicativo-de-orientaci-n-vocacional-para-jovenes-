<?php

namespace App\Models;

use CodeIgniter\Model;

class TestVocacionalModel extends Model
{
    protected $table = 'Test_Vocacional';
    protected $primaryKey = 'id_test';

    protected $allowedFields = [
        'nombre_test',
        'descripcion'
    ];

    protected $useTimestamps = false;
}
