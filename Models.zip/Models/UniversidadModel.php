<?php

namespace App\Models;

use CodeIgniter\Model;

class UniversidadModel extends Model
{
    protected $table = 'Universidad';
    protected $primaryKey = 'id_universidad';

    protected $allowedFields = [
        'nomre_uni',
        'ciudad',
        'direccion',
        'telefono'
    ];

    protected $useTimestamps = false;