<?php

namespace App\Models;

use CodeIgniter\Model;

class UsuarioModel extends Model
{
   protected $table = 'Usuario';
    protected $primaryKey = 'id_usuario';

    protected $allowedFields = [
        'nombres',
        'apellidos',
        'edad',
        'correo',
        'contraseña',
        'grado_escolar'
    ];

    protected $useTimestamps = false;
}
